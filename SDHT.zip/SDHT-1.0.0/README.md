# SDHT
Class for DHT11, DHT12, DHT21, DHT22 sensors

# TESTED ON

arduino uno

ESP8266 D1 mini - not working... working...

DHT22
