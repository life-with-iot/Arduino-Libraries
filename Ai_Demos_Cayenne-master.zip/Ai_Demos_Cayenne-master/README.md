# Ai_Demos_Cayenne

Example code for using myDevices Cayenne platform with various electronic and 
mechanical components.

## Description

For more details, check out the tutorials at:

    * https://www.youtube.com/playlist?list=PLNFq0T6Z3JPsionMHq-YSU6Kva3hhxxAh

Developed by MakerBro for ACROBOTIC Industries.  Please consider buying 
products from us to help fund future Open-Source projects like this! We'll
always put our best effort in every project, and release all our design 
files and code for you to use. 

Visit our online shop, which is located at:

   * https://acrobotic.com/

## License

Released under the MIT license. Please check LICENSE.txt for more information. 
All text above must be included in any redistribution.
