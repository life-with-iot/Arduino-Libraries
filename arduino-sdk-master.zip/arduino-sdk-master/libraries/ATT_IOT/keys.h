/****
 * Enter your AllThingsTalk device credentials below
 */
#ifndef KEYS_h
#define KEYS_h

const char* DEVICE_ID = "tGktx5JYUwr3RJPe5svqpksJ";
const char* DEVICE_TOKEN = "maker:4PZ39OTuPyzJO0Nw7zpI373Xbu6YBKuBgh3LlJY1";

#endif