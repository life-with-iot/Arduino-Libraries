const images = {
    loginSplash: require('../images/mydevices.png'),
    logo: require('../images/myDevicesWhite.png'),
    gatewaySetup: require('./../images/graphic-gateway-setup.png'),
    gatewayPlacement: require('./../images/graphic-gateway-placement.png'),
    elsysSensor: require('./../images/graphic-setup-elsys.png')
}

export default images;
