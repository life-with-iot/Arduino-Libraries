var session = {
    access_token: '',
    refresh_token: '',
    mqqt_id: '',
    mqqt_secret: ''
}

export default session;
