import {
    AppRegistry
} from 'react-native';
import App from './app';
//import NavigatorService from './js/lib/navigation.service';

AppRegistry.registerComponent(
    'CayenneSampleApp', 
    () => App
);
